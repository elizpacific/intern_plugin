var config = {
    map: {
        '*': {
            'Magento_OfflinePayments/js/view/payment/offline-payments':'Mageplaza/view/frontend/web/js/offline-payments',
        }
    }
};
