<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mageplaza_Payment',
    __DIR__
);
require_once (__DIR__ . '/vendor/autoload.php');
//require_once 'ginger-php/vendor/autoload.php';
